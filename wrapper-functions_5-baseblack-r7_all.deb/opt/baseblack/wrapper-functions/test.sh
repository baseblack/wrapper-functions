#!/bin/bash -x

#~ source ./bb_args

#~ bb_getopts $@
#~ echo $BB_ARGS

source ./bb_tankloader
bb_tankbootstrap foundry nuke 6.3